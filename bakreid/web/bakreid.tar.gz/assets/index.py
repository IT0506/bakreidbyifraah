import pygame
import sys
import random
import asyncio

WIDTH, HEIGHT = 900, 600

WHITE = (255, 255, 255)
SKY = (10, 10, 40)
YELLOW = (255, 215, 0)
GREEN = (20, 120, 40)
BLACK = (0, 0, 0)
GRAY = (220, 220, 220)
BROWN = (139, 69, 19)

async def main():

    pygame.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Eid-ul-Adha Mubarak")

    clock = pygame.time.Clock()

    title_font = pygame.font.SysFont("georgia", 56, bold=True)
    subtitle_font = pygame.font.SysFont("comicsansms", 42, bold=True)

    # stars
    stars = [(random.randint(0, WIDTH),
              random.randint(0, HEIGHT//2),
              random.randint(1, 3)) for _ in range(80)]

    def create_goat():
        goat = pygame.Surface((140, 100), pygame.SRCALPHA)
        pygame.draw.ellipse(goat, GRAY, (40, 35, 75, 45))
        pygame.draw.ellipse(goat, (235,235,235), (5,25,55,45))
        return goat

    goat_img = create_goat()

    def create_moon():
        moon = pygame.Surface((120, 120), pygame.SRCALPHA)
        pygame.draw.circle(moon, YELLOW, (60, 60), 45)
        return moon

    moon_img = create_moon()

    def create_cloud():
        cloud = pygame.Surface((140, 70), pygame.SRCALPHA)
        pygame.draw.ellipse(cloud, WHITE, (0, 25, 140, 35))
        return cloud

    cloud_img = create_cloud()

    goat_x1 = -150
    goat_x2 = WIDTH + 150
    cloud_x = 0

    running = True

    while running:

        screen.fill(SKY)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # stars
        for s in stars:
            pygame.draw.circle(screen, WHITE, (s[0], s[1]), s[2])

        # moon
        screen.blit(moon_img, (WIDTH//2 - 60, 40))

        # clouds
        cloud_x -= 0.4
        if cloud_x < -200:
            cloud_x = WIDTH

        screen.blit(cloud_img, (cloud_x, 100))

        # goats
        goat_x1 += 1
        goat_x2 -= 1

        if goat_x1 > WIDTH:
            goat_x1 = -150
        if goat_x2 < -150:
            goat_x2 = WIDTH

        screen.blit(goat_img, (goat_x1, HEIGHT-165))
        screen.blit(goat_img, (goat_x2, HEIGHT-165))

        # text
        t = title_font.render("Eid-ul-Adha", True, YELLOW)
        s = subtitle_font.render("Mubarak", True, WHITE)

        screen.blit(t, (WIDTH//2 - t.get_width()//2, 420))
        screen.blit(s, (WIDTH//2 - s.get_width()//2, 485))

        pygame.display.flip()
        clock.tick(60)

        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

asyncio.run(main())